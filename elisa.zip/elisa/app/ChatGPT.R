
# ChatGPT

# 1、热图
library(ggplot2)
library(reshape2)

data <- data.frame(x = 1:10, y = 1:10, z = rnorm(100))
ggplot(data, aes(x, y, fill = z)) +
  geom_tile() +
  scale_fill_gradient(low = "white", high = "red") +
  labs(x = "X Axis", y = "Y Axis", title = "Heat Map")

# 2、方差分析
set.seed(123)
group1 <- rnorm(30, mean = 10, sd = 2)
group2 <- rnorm(30, mean = 15, sd = 3)
group3 <- rnorm(30, mean = 20, sd = 4)

data <- data.frame(value=c(group1,group2,group3), group=c(rep("Group1",30),rep("Group2",30),rep('Group3',30)))

anova_result <- aov(value ~ group, data = data)
summary(anova_result)

library(ggplot2)
ggplot(data, aes(x=group, y=value,fill = group)) +
  geom_boxplot() +
  geom_point(color = 'black',size= .5, shape=1) +
  stat_compare_means(method = 'anova' )+
  xlab("Group") +
  ylab("Value") +
  ggtitle("Boxplot by Group")

